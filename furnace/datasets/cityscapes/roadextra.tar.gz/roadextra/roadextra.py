#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2019/9/19 下午8:41
# @Author  : dong nie
# @Contact : dongnie@cs.unc.edu
# @File    : cityscapes.py
import numpy as np

from datasets.BaseDataset import BaseDataset


class RoadExtra(BaseDataset):
    trans_labels = [0,1,2,3,4,5,6,7,8]

    @classmethod
    def get_class_colors(*args):
        return [[0,0,0],  #Unknown
                [0,255,255],  #Urban land
                [255,255,0],  #Agriculture land
                [255,0,255],  #Rangeland
                [0,255,0],  #Forest land
                [0,0,255],  #Water
                [255,0,0], #Barren land
                [0, 0, 255],  # Barren land
                [255, 0, 0],  # Barren land
                ]

    @classmethod
    def get_class_names(*args):
        return ['Unknown', 'Urban land', 'Agriculture land', 'Rangeland', 'Forest land'
                'Water', 'Barren land','Wall','Road']

    # @classmethod
    # def transform_label(cls, pred, name):
    #     label = np.zeros(pred.shape)
    #     ids = np.unique(pred)
    #     for id in ids:
    #         label[np.where(pred == id)] = cls.trans_labels[id]

    #     new_name = (name.split('.')[0]).split('_')[:-1]
    #     new_name = '_'.join(new_name) + '.png'

    #     return label, new_name