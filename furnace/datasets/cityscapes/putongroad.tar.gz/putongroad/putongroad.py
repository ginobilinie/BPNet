#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2019/11/18 下午8:41
# @Author  : yuchangqian
# @Contact : changqian_yu@163.com
# @File    : putongroad.py
import numpy as np

from datasets.BaseDataset import BaseDataset


class Putongroad(BaseDataset):
    # trans_labels = [7, 8, 11, 12, 13, 17, 19, 20, 21, 22, 23, 24, 25, 26, 27,
    #                 28, 31, 32, 33]

    @classmethod
    def get_class_colors(*args):
        return [[255, 255, 10], [255, 135, 205], [202, 135, 216],
                [255, 105, 205], [0, 255, 255], [132, 227, 255],
                [18, 153, 255], [220, 220, 0], [0, 0, 90],
                [0, 255, 0], [196, 196, 196], [190, 153, 153],
                [102, 102, 156],[0, 60, 100], [105, 128, 118],
                [20, 40, 80], [40, 200, 30],[40, 200, 30],
                [120, 28, 118],[70, 150, 50],[180, 200, 80],
                [110, 23, 118], [70, 120, 240], [120, 90, 200],
                [50, 50, 200], [200, 200, 118], [150, 210, 70],
                [70, 240, 70], [132, 255, 118], [100, 150, 240]
                ]

    @classmethod
    def get_class_names(*args):
        return ['0','1','2','3','4','5',
                '6','7','8','9','10','11','12',
                '13','14','15','16','17','18',
                '19','20','21','22','23','24',
                '25','26','27','28','29'
                ]

    # @classmethod
    # def transform_label(cls, pred, name):
    #     label = np.zeros(pred.shape)
    #     ids = np.unique(pred)
    #     for id in ids:
    #         label[np.where(pred == id)] = cls.trans_labels[id]
    #
    #     new_name = (name.split('.')[0]).split('_')[:-1]
    #     new_name = '_'.join(new_name) + '.png'
    #
    #     return label, new_name